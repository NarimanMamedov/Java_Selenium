import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.time.Duration;

public class SeleniumTestsForOrange {

    @Test
    public void seleniumTest() throws InterruptedException {
        // -------  Arrange -------
        ChromeOptions options = new ChromeOptions();
        //options.setImplicitWaitTimeout(Duration.ofMillis(3000000));
        options.setPageLoadStrategy(PageLoadStrategy.NORMAL);
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();

        final String userNameInputLocator = "//input[@name='username' and @placeholder='Username']";
        final String userPasswordInputLocator = "//input[@name='password']";
        final String baseURL = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
        final String userName = "Admin";
        final String userPassword = "admin123";
        final String buttonLoginLocator = "//button[@class='oxd-button oxd-button--medium oxd-button--main orangehrm-login-button']";

        final String expectedTitle = "OrangeHRM";
        final String expectedURL = "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index";
        String actualTitle = "";
        String actualURL = "";


        // --------  Act -------
        try {
            driver.get(baseURL);
            Thread.sleep(3000);

            WebElement loginField = driver.findElement(By.xpath(userNameInputLocator));
            loginField.sendKeys(userName);
            WebElement passwordField = driver.findElement(By.xpath(userPasswordInputLocator));
            passwordField.sendKeys(userPassword);
            WebElement buttonLogin = driver.findElement(By.xpath(buttonLoginLocator));
            buttonLogin.click();

            actualTitle = driver.getTitle();
            actualURL = driver.getCurrentUrl();

        } catch (Error e) {
            System.out.println(e.getMessage());
        } finally {
            driver.quit();
        }

        // -------  Assert -------
        Assertions.assertEquals(expectedTitle, actualTitle);
        Assertions.assertEquals(expectedURL, actualURL);
    }
}
