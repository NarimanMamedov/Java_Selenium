package gui.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
    private final WebDriver driver;
    private final String pageURL = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
    private final By userNameInputLocator = By.xpath("//input[@name='username' and @placeholder='Username']");
    private final By userPasswordInputLocator = By.xpath("//input[@name='password']");
    private final By buttonLoginLocator = By.xpath("//button[@class='oxd-button oxd-button--medium oxd-button--main orangehrm-login-button']");
    private final By invalidCredentialTextLocator = By.xpath(" //p [text() = 'Invalid credentials']");
    private final By invalidCredentialAlertLocator = By.xpath("//div [@role = 'alert']");
    private final By forgotYourPasswordLocator = By.xpath("//div [@class='orangehrm-login-forgot']/child::p[1]");

    public LoginPage (WebDriver driver){
        this.driver = driver;
    }

    public void open(){
        this.driver.get(this.pageURL);
    }

    public void setUserName(String name){
        this.driver.findElement(this.userNameInputLocator).sendKeys(name);
    }

    public void setUserPassword(String password){
        this.driver.findElement(this.userPasswordInputLocator).sendKeys(password);
    }

    public void pressLoginButton (){
        this.driver.findElement(this.buttonLoginLocator).click();
    }

    public String getMessageWhenCredentialIsWrong(){
        return this.driver.findElement(this.invalidCredentialTextLocator).getText();

    }

    public boolean checkIsDisplayedInvalidCredentialAlertElement(){
        return this.driver.findElement(this.invalidCredentialAlertLocator).isDisplayed();
    }

    public void clickForgotYourPasswordLink (){
        this.driver.findElement(forgotYourPasswordLocator).click();
    }

}
