import gui.pages.LoginPage;
import gui.steps.LoginSteps;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.time.Duration;

public class InvalidCredentialsTest {

    @Test
    public void InvalidCredsTest() throws InterruptedException {
        // -------  Arrange -------
        ChromeOptions options = new ChromeOptions();
        options.setImplicitWaitTimeout(Duration.ofMillis(30000));
        options.setPageLoadStrategy(PageLoadStrategy.NORMAL);
        WebDriver driver = new ChromeDriver(options);
        driver.manage().window().maximize();

        LoginPage loginPage = new LoginPage(driver);
        LoginSteps loginSteps = new LoginSteps(driver);

        String actualTextMessage = "";
        boolean isInvalidCredentialAlertElementVisible = false;

        // --------  Act -------
        try {
            loginPage.open();
            loginSteps.login("1", "1");

            actualTextMessage = loginPage.getMessageWhenCredentialIsWrong();
            isInvalidCredentialAlertElementVisible = loginPage.checkIsDisplayedInvalidCredentialAlertElement();

        } catch (Error e) {
            System.out.println(e.getMessage());
        } finally {
            driver.quit();
        }

        // -------  Assert -------
        Assertions.assertEquals("Invalid credentials", actualTextMessage);
        Assertions.assertTrue(isInvalidCredentialAlertElementVisible);
    }
}

