import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class UpdateContactInformationTest {

    @Test
    public void checkThatNewContactDataSaved() throws InterruptedException {
        // -------  Arrange -------
        ChromeOptions options = new ChromeOptions();
        options.setImplicitWaitTimeout(Duration.ofMillis(30000));
        options.setPageLoadStrategy(PageLoadStrategy.NORMAL);
        WebDriver driver = new ChromeDriver(options);
        driver.manage().window().maximize();

        final String userNameInputLocator = "//input[@name='username' and @placeholder='Username']";
        final String userPasswordInputLocator = "//input[@name='password']";
        final String baseURL = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
        final String userName = "Admin";
        final String userPassword = "admin123";
        final String buttonLoginLocator = "//button[@class='oxd-button oxd-button--medium oxd-button--main orangehrm-login-button']";
        final String itemMyInfoLocator = "//a [contains (span, 'My Info')]/parent::*";
        final String itemContactDetailsLocator = "//div [contains (a, 'Contact Details')]";
        final String fieldStreet2Locator = "//div [contains (label, 'Street 2')]/following::div[1]/input";
        final String fieldStateProvinceLocator = "//div [contains (label, 'State/Province')]/following::input[1]";
        final String fieldHomeLocator = "//div [contains (label, 'Home')]/following::input[1]";
        final String buttonSaveLocator = "//button [text() = ' Save ']";
        String actualStreet2 = "";
        String actualStateProvince = "";
        String actualHome = "";
        String a = "";

        // --------  Act -------
        try {
            driver.get(baseURL);
            WebElement loginField = driver.findElement(By.xpath(userNameInputLocator));
            loginField.sendKeys(userName);
            WebElement passwordField = driver.findElement(By.xpath(userPasswordInputLocator));
            passwordField.sendKeys(userPassword);
            WebElement buttonLogin = driver.findElement(By.xpath(buttonLoginLocator));
            buttonLogin.click();
            WebElement linkMyInfo = driver.findElement(By.xpath(itemMyInfoLocator));
            linkMyInfo.click();
            WebElement linkContactDetails = driver.findElement(By.xpath(itemContactDetailsLocator));
            linkContactDetails.click();

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofMillis(300000));
            wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(fieldStreet2Locator)));
            WebElement fieldStreet2 = driver.findElement(By.xpath(fieldStreet2Locator));

            //fieldStreet2.sendKeys("value", "");


            JavascriptExecutor j = (JavascriptExecutor)driver;
            j.executeScript("arguments[0].value='';", fieldStreet2);


            Thread.sleep(5000);
            new Actions(driver)
                    .click(fieldStreet2)
                    //.sendKeys("value", "")
                    //.sendKeys(Keys.CONTROL, "a")
                    //.sendKeys(Keys.DELETE)
                    .sendKeys("St. Lvivska 49")
                    .perform();
            WebElement fieldStateProvence = driver.findElement(By.xpath(fieldStateProvinceLocator));
            fieldStateProvence.clear();
            new Actions(driver)
                    .click(fieldStateProvence)
                    .sendKeys("Lvivska district")
                    .perform();
            WebElement fieldHome = driver.findElement(By.xpath(fieldHomeLocator));
            Thread.sleep(5000);
            fieldHome.clear();
            new Actions(driver)
                    .click(fieldHome)
                    .sendKeys("16")
                    .perform();

            driver.findElement(By.xpath("//div[@class='oxd-select-text-input']")).click();
            Thread.sleep(2000);
            WebElement countryItem = driver.findElement(By.xpath("//div[@role='listbox']//*[text()='Algeria']"));
            // System.out.println("===> ELEMENT TAG: " + countryItem.getTagName());

            List<WebElement> countryItems = driver.findElements(By.xpath("//div[@role='listbox']//span"));
            for(WebElement item : countryItems) {
                System.out.println("===> Country form the list: " + item.getText());
                if (item.getText().equals("Ukraine")){
                    item.click();
                    break;
                }
            }
            //countryItem.click();

            Thread.sleep(3000);


            WebElement fieldSave = driver.findElement(By.xpath(buttonSaveLocator));
            new Actions(driver)
                    .click(fieldSave)
                    .perform();
            Thread.sleep(5000);
            driver.navigate().refresh();


            WebElement actualStreet2We = driver.findElement(By.xpath(fieldStreet2Locator));
            a = actualStreet2We.getAttribute("value");
//             new Actions(driver)
//                    .click(actualStreet2WE)
//                    .sendKeys(Keys.CONTROL, "a")
//                    .sendKeys(Keys.CONTROL, "c")
//                    .perform();
//            Toolkit toolkit = Toolkit.getDefaultToolkit();
//            Clipboard clipboard = toolkit.getSystemClipboard();
//            String copyFromClipboard= (String) clipboard.getData(DataFlavor.stringFlavor);
//            System.out.println("String from Clipboard:" + result);
//            YourWebElement.sendkeys(copyFromClipboard);

            actualStateProvince = driver.findElement(By.xpath(fieldStateProvinceLocator)).getText();
            actualHome = driver.findElement(By.xpath(fieldHomeLocator)).getText();



        } catch (Error e) {
            System.out.println(e.getMessage());
        } finally {
            driver.quit();
        }

        // -------  Assert -------
        Assertions.assertEquals("St. Lvivska 49", a);
        Assertions.assertEquals("Lvivska district", actualStateProvince);
        Assertions.assertEquals("16", actualHome);


    }
}
