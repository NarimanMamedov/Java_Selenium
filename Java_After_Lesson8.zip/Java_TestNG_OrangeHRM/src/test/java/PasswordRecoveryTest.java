import gui.pages.ConfirmationResetPasswordPage;
import gui.pages.LoginPage;
import gui.pages.ResetPasswordPage;
import org.junit.jupiter.api.*;
import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.time.Duration;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class PasswordRecoveryTest {

    private WebDriver driver;
    private ResetPasswordPage resetPasswordPage;
    private ConfirmationResetPasswordPage confirmationResetPasswordPage;
    private LoginPage loginPage;


    //@BeforeAll
    @BeforeEach
    public void setup() throws InterruptedException {

        ChromeOptions options = new ChromeOptions();
        options.setImplicitWaitTimeout(Duration.ofMillis(30000));
        options.setPageLoadStrategy(PageLoadStrategy.NORMAL);
        driver = new ChromeDriver(options);
        driver.manage().window().maximize();

        loginPage = new LoginPage(driver);
        loginPage.open();
        loginPage.clickForgotYourPasswordLink();

        resetPasswordPage = new ResetPasswordPage(driver);
    }

    //@AfterAll
    @AfterEach
    public void closeDriver() {
        driver.quit();
    }


    @Test
    public void validateResetPasswordForm() throws InterruptedException {
        // -------  Arrange -------

        final String expectedResetPasswordURL = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/requestPasswordResetCode";
        String actualNameResetPasswordWindow = "";
        String actualURL = "";
        String actualNameFromButtonCancel = "";

        // --------  Act -------
        try {
            actualURL = resetPasswordPage.getPageUrl();
            actualNameResetPasswordWindow = resetPasswordPage.getModalWindowName();
            actualNameFromButtonCancel = resetPasswordPage.getCancelButtonText();

        } catch (Error e) {
            System.out.println(e.getMessage());
        }

        // -------  Assert -------

        Assertions.assertEquals(expectedResetPasswordURL, actualURL);
        Assertions.assertEquals("Reset Password", actualNameResetPasswordWindow);
        Assertions.assertNotNull(actualNameFromButtonCancel);
        Assertions.assertNotNull(resetPasswordPage.getResetButtonText());
        Assertions.assertNotNull(resetPasswordPage.getActualUserNameInputField());
        Thread.sleep(3000);
    }

    @Test
    public void TestFunctionalityOfResetPasswordForm() throws InterruptedException {
        // -------  Arrange -------
        final String userName = "Admin";
        WebElement formTitle = null;
        confirmationResetPasswordPage = new ConfirmationResetPasswordPage(driver);
        // -------  Act -------
        try {
            resetPasswordPage.setUserName(userName);
            resetPasswordPage.clickResetPasswordButton();
            formTitle = confirmationResetPasswordPage.getFormTitleElement();

        } catch (Error e) {
            System.out.println(e.getMessage());
        }
        // -------  Assert -------
        Assertions.assertNotNull(formTitle);
        //Thread.sleep(3000);

    }
}
