package gui.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ConfirmationResetPasswordPage {
    private final WebDriver driver;

    private final By formTitleLocator = By.xpath("//h6 [text() = 'Reset Password link sent successfully']");

    public ConfirmationResetPasswordPage (WebDriver driver){
        this.driver = driver;
    }

    public WebElement getFormTitleElement(){
        return  driver.findElement(formTitleLocator);
    }
}
