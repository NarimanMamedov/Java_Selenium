package gui.steps;

import gui.pages.LoginPage;
import org.openqa.selenium.WebDriver;

public class LoginSteps {
    LoginPage loginPage;
    public LoginSteps(WebDriver driver){
        this.loginPage =new LoginPage(driver);
    }
    public void login (String userName, String userPassword){
        loginPage.setUserName(userName);
        loginPage.setUserPassword(userPassword);
        loginPage.pressLoginButton();
    }

}
