package gui.steps;

import gui.pages.LoginPage;

public abstract class BaseSteps {
    protected LoginPage loginPage = new LoginPage();
}
