package gui.steps;

import gui.pages.Menu;

public class MenuSteps extends BaseSteps{
    private Menu menu = new Menu();

    public void clickOnMyInfoMenu (){
        menu.clickOnMyInfoMenu();
    }
}
