
import base.BaseTest;
import gui.steps.ContactDetailsSteps;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class UpdateContactInformationTest extends BaseTest {
    private ContactDetailsSteps contactDetailsSteps;


    @Test
    public void checkThatNewContactDataSaved() throws InterruptedException {
        contactDetailsSteps = new ContactDetailsSteps();
        // -------  Arrange -------

        final String userName = "Admin";
        final String userPassword = "admin123";
        String street2Value = "St. Lvivska 49";
        String stateProvinceValue = "Lvivska district";
        String homeValue = "16";
        String country = "Ukraine";

        // --------  Act -------

        contactDetailsSteps.openContactDetailsPage(userName,userPassword);
        contactDetailsSteps.setStreet2TextFieldValue(street2Value);
        contactDetailsSteps.setStateProvinceTextFieldValue(stateProvinceValue);
        contactDetailsSteps.setCountryInDropdown(country);
        contactDetailsSteps.setHomeTextFieldValue(homeValue);
        contactDetailsSteps.saveChangesAndRefreshPage();

//            JavascriptExecutor j = (JavascriptExecutor)driver;
//            String fieldStreet2Value = (String) j.executeScript("arguments[0].value='';", fieldStreet2);

        // -------  Assert -------
        Assertions.assertEquals(street2Value, contactDetailsSteps.getFieldStreet2Value());
        Assertions.assertEquals(stateProvinceValue, contactDetailsSteps.getFieldStateProvinceValue());
        Assertions.assertEquals(homeValue, contactDetailsSteps.getFieldHomeValue());
    }
}
