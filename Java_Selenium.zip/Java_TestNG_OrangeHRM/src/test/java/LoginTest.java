import base.BaseTest;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class LoginTest extends BaseTest {

    @Test
    public void seleniumTest() {
        // -------  Arrange -------

        final String userName = "Admin";
        final String userPassword = "admin123";
        final String expectedTitle = "OrangeHRM";
        final String expectedURL = "https://opensource-demo.orangehrmlive.com/web/index.php/dashboard/index";

        // --------  Act -------
            loginSteps.open();
            loginSteps.login(userName, userPassword);
            String actualTitle = loginSteps.getPageTitle();
            String actualURL = loginSteps.getPageURL();

        // -------  Assert -------
        Assertions.assertEquals(expectedTitle, actualTitle);
        Assertions.assertEquals(expectedURL, actualURL);
    }
}
