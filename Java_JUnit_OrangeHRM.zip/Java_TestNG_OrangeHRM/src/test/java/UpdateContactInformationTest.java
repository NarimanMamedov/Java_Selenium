public class UpdateContactInformationTest {
}
