import org.junit.jupiter.api.*;
import org.openqa.selenium.By;
import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import java.time.Duration;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class PasswordRecoveryTest {

    private WebDriver driver;
    private WebElement actualUserNameInputField;
    private WebElement actualNameFromResetPasswordButton;

    //@BeforeAll
    @BeforeEach
    public void setup() throws InterruptedException {
        final String baseURL = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
        final String forgotYourPasswordLocator = "//div [@class='orangehrm-login-forgot']/child::p[1]";
        final String inputFieldUserNameLocator = "//input[@name='username' and @placeholder='Username']";
        final String buttonResetPasswordLocator = "//button [text() = ' Reset Password ']";

        ChromeOptions options = new ChromeOptions();
        options.setImplicitWaitTimeout(Duration.ofMillis(30000));
        options.setPageLoadStrategy(PageLoadStrategy.NORMAL);
        driver = new ChromeDriver(options);
        driver.manage().window().maximize();
        driver.get(baseURL);

        WebElement forgotYourPasswordLink = driver.findElement(By.xpath(forgotYourPasswordLocator));
        forgotYourPasswordLink.click();
        actualUserNameInputField = driver.findElement(By.xpath(inputFieldUserNameLocator));
        actualNameFromResetPasswordButton = driver.findElement(By.xpath(buttonResetPasswordLocator));
    }

    //@AfterAll
    @AfterEach
    public void closeDriver() {
        driver.quit();
    }


    @Test
    public void validateResetPasswordForm() throws InterruptedException {
        // -------  Arrange -------

        final String expectedResetPasswordURL = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/requestPasswordResetCode";
        final String expectedNameModalWindow = "//h6 [text()='Reset Password']";
        final String buttonCancelLocator = "//button [text() = ' Cancel ']";

        String actualNameResetPasswordWindow = "";
        String actualURL = "";
        WebElement actualNameFromButtonCancel = null;

        // --------  Act -------
        try {
            actualURL = driver.getCurrentUrl();
            actualNameResetPasswordWindow = driver.findElement(By.xpath(expectedNameModalWindow)).getText();
            actualNameFromButtonCancel = driver.findElement(By.xpath(buttonCancelLocator));


        } catch (Error e) {
            System.out.println(e.getMessage());
        }

        // -------  Assert -------

        Assertions.assertEquals(expectedResetPasswordURL, actualURL);
        Assertions.assertEquals("Reset Password", actualNameResetPasswordWindow);
        Assertions.assertNotNull(actualNameFromButtonCancel);
        Assertions.assertNotNull(actualNameFromResetPasswordButton);
        Assertions.assertNotNull(actualUserNameInputField);
        Thread.sleep(3000);
    }

    @Test
    public void TestFunctionalityOfResetPasswordForm() throws InterruptedException {
        // -------  Arrange -------
        final String userName = "Admin";
        final String formTitleLocator = "//h6 [text() = 'Reset Password link sent successfully']";
        WebElement formTitle = null;
        // -------  Act -------
        try {
            actualUserNameInputField.sendKeys(userName);
            actualNameFromResetPasswordButton.click();
            formTitle = driver.findElement(By.xpath(formTitleLocator));

        } catch (Error e) {
            System.out.println(e.getMessage());
        }
        // -------  Assert -------
        Assertions.assertNotNull(formTitle);
        Thread.sleep(3000);

    }
}
